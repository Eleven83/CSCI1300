////////////////////////////////
//  UNIVERSITY OF COLORADO    //
//  CSCI 1300                 //
//  INSTRUCTOR: DR. KNOX      //
//  TA: STEPHEN HUTT          //
//  ASSIGNMENT 8/C++ PROJECT  //
//  AUTHOR: Ryan A. Hoffman   //
////////////////////////////////
#include <iostream>
#include "Restaurant.h"
#include "Inventory.h"

using namespace std;

int main()
{
    Restaurant r1;
    r1.mainMenu();
    return 0;
}
